package android.support.localbroadcastmanager;

/* renamed from: android.support.localbroadcastmanager.R */
public final class C0257R {
    private C0257R() {
    }
}
