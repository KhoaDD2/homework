package android.support.interpolator;

/* renamed from: android.support.interpolator.R */
public final class C0246R {
    private C0246R() {
    }
}
