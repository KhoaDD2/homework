package android.support.localbroadcastmanager;

/* renamed from: android.support.localbroadcastmanager.R */
public final class C0250R {
    private C0250R() {
    }
}
