package android.support.cursoradapter;

/* renamed from: android.support.cursoradapter.R */
public final class C0232R {
    private C0232R() {
    }
}
